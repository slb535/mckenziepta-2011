
<div id="aside2">
    
    <div id="rss">
    <ul><li><a href="<?php bloginfo('rss2_url'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/rss.png" border="0" class="secondary_aside" alt="Subscribe to <?php bloginfo('name'); ?>" />Subscribe to our <BR />RSS Feed</a> 
        </li></ul>
</div>
    
<div id="longtermlinks" >
    
   
     <ul>
        <li><a href="">Lunch Menu</a></li>
        <li><a href="">Variety Show</a></li>
      </ul>

  
    <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Widgets')) : else : ?>
    
        <!-- All this stuff in here only shows up if you DON'T have any widgets active in this zone -->
        <ul>
<?php
$postlist = get_posts('category=112&numberposts=5');
foreach ($postlist as $post) :
?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>    
        </ul>
        
    	<!-- <?php wp_list_pages('title_li=<h2>Pages</h2>' ); ?>
     <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) { the_post_thumbnail(array(100,100), array("class" => "thumbnail")); } ?>

    
    	<h2>Archives</h2>
    	<ul>
    		<?php wp_get_archives('type=monthly'); ?>
    	</ul>
        
       
        
    	<?php wp_list_bookmarks(); ?>
    
    	<h2>Meta</h2>
    	<ul>
    		<?php wp_register(); ?>
    		<li><?php wp_loginout(); ?></li>
    		<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
    		<?php wp_meta(); ?>
    	</ul>
    	
    	<h2>Subscribe</h2>
    	<ul>
    		<li><a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a></li>
    		
    	</ul>-->
	
	<?php endif; ?> 

</div>
    </div>