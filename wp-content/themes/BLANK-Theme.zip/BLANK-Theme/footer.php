		
<BR><BR>
            <div id="footer">
               
		<div id="copyright">
			&copy;<?php echo date("Y"); echo " "; bloginfo('description'); ?>   <br />  
                       Web Site Support: <a href="mailto:webmaster@mckenziepta.com">webmaster@mckenziepta.com</a>  |    
                       PTA-Related Questions or Concerns: <a href="mailto:AskCheetah@McKenziePTA.com ">AskCheetah@McKenziePTA.com</a>
                           
                           
		</div> 

	</div>

	<?php wp_footer(); ?>
	
	<!-- Don't forget analytics -->
	
</body>

</html>
