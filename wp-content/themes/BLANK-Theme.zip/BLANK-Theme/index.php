<?php get_header(); ?>

<div id="main-content" class="group"> <!--wraps the stuff in the white - left sidebar, center, right sidebar -->
       
     <aside>
         
        <ul>
            <li ><a href=""><img src="images/grocerydollars.png" width="30"  height="26" align="left" border="0" />
                    Grocery Dollars</a></li>
                <p class="descr">The easiest way to raise
                money for school. Doesn't cost you a cent!</p>
            	<li><a href="">Birthday Books</a></li>
                <li><a href="">PTA Membership and Directory</a></li>
                <p class="descr">Join the PTA and get your student directory today.</p>
             
            	<li><a href="">Getting to Know McKenzie</a> </li>
                <li><a href="">Order everything at once:</a></li>
                 <p class="descr">Birthday Books, PTA Membership and Yearbook in one fell swoop!</p>
         </ul>  
         
         
         <hr></hr>
         
         
         <ul> 
             <li><img src="images/clipboard.png" width="30"  height="26" align="left" border="0" />
                 <a href="" class="secondary_aside">Cafeteria Duty <BR>Sign Up</a></li>
             <li><img src="images/yearbook.png" width="30" height="26" align="left" border="0" style="padding-bottom: 10px" />
                 <a href="https://images.jostens.com/login?user=400112435&pw=photos"  class="secondary_aside" target="new">Upload Yearbook <BR>Pictures</a></li>
             
             
         </ul>
      </aside>	
    
    
<?php get_sidebar(); ?>
    
    
<div id="article-list" >
    <?php query_posts($query_string . '&cat=-115'); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


    
    <div <?php post_class() ?> id="post-<?php the_ID(); ?>">

			 
                            <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) { the_post_thumbnail(array(75,75), array("class" => "thumbnail")); } ?>

                            <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

                            
                            
		
			<div class="entry">
                          




			
                        <?php the_content("Read more . . ."); ?>
                           
                            
			</div>

                        <div class="date"> 
                            
                            <div class="postmetadata">
				
                            Posted on: <?php the_time('F jS, Y') ?>
						</div>
                        
                        </div>
                        

		</div>

	<?php endwhile; ?>

	<?php include (TEMPLATEPATH . '/inc/nav.php' ); ?>

	<?php else : ?>

	<h2>Page Not Available Yet</h2>
                
                <p>We are in the process of updating all of the content for the new school year. We hope to have current information on this topic very very soon. Please check back or <a href="<?php bloginfo('rss2_url'); ?>">subscribe to our RSS feed</a>.


	<?php endif; ?>
                
                			
   <?php get_footer(); ?><BR /><BR />
                
           </div> <!-- end main-content -->	         
 

                
               

	
</div> <!-- END center-wrap -->


                 

