<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div>
        <input type="text" id="s" name="s" value="" />
        
        <input type="submit" value="Go" id="searchsubmit" /><BR>
                <label for="s" class="screen-reader-text">search mckenziepta.com</label>

    </div>
</form>