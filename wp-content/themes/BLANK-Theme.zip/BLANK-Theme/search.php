<?php get_header(); ?>
<div id="main-content"> <!--wraps the stuff in the white - left sidebar, center, right sidebar -->

    <div id="page-article">

	<?php if (have_posts()) : ?>

		<h2>Search Results</h2>

		<?php include (TEMPLATEPATH . '/inc/nav.php' ); ?>

		<?php while (have_posts()) : the_post(); ?>

			<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

				<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

				<?php include (TEMPLATEPATH . '/inc/meta.php' ); ?>

				<div class="entry">
					<?php the_excerpt(); ?>
                          

			
                        <?php the_content("Read more . . ."); ?>
                           
                            
			</div>

                        <div class="date"> 
                            
                            <div class="postmetadata">
				
                            Posted on: <?php the_time('F jS, Y') ?>
						</div>
                        
                        </div>
                        
			</div>

		<?php endwhile; ?>


	<?php else : ?>

		<h2>Sorry, no pages were found.</h2>

	<?php endif; ?>

</div>
    
<?php get_sidebar(); ?>
    	
</div> <!-- END center-wrap -->

<?php get_footer(); ?> 