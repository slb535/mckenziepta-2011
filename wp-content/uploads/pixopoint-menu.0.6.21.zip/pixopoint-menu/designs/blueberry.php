<?php

/*
	This file loads a new design
	Note: No this file does not need to be a PHP script, but why the heck not?

	PixoPoint Menu Plugin
	Copyright (c) 2009 PixoPoint Web Development

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License version 2 as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

?>menu1_height=40|menu1_background_image=../images/dazzle_blue.png|menu1_background_colour=#203FA0|menu1_wrapperwidth=100|menu1_percent_wrapperwidth=%|menu1_containerwidth=100|menu1_percent_containerwidth=%|menu1_alignment=right|menu1_background_buttoncolour=#203FA0|menu1_background_buttonimage=../images/dazzle_blue.png|menu1_backgroundhovercolour=#4867C8|menu1_graphicalhover=on|menu1_button_betweenpadding=5|menu1_button_withinpadding=15|menu1_fontfamily=Georgia,serif|menu1_fontsize=16|menu1_fontweight=off|menu1_fontitalics=off|menu1_links_underline=Never underlined|menu1_texttransform=|menu1_letter_spacing=2|menu1_colour=#FFFFFF|menu1_hovercolour=#FFFFFF|menu1_dropdown_fontfamily=helvetica,arial,sans-serif|menu1_dropdown_textcolour=#262626|menu1_dropdown_texthovercolour=#FFFFFF|menu1_dropdown_backgroundcolour=#FFFFFF|menu1_dropdown_backgroundhovercolour=#203FA0|menu1_dropdown_width=130|menu1_dropdown_opacity=100|menu1_dropdown_paddingvertical=6|menu1_dropdown_paddinghorizontal=8|menu1_shadow_width=12|menu1_dropdown_fontsize=11|menu1_dropdown_bold=off|menu1_dropdown_italics=off|menu1_dropdown_texttransform=|menu1_dropdown_letter_spacing=0|menu1_dropdown_underline=Never underlined|menu1_dropdown_borderwidth=1|menu1_dropdown_bordercolour=#999999|
