<?php

/*
	This file loads a new design
	Note: No this file does not need to be a PHP script, but why the heck not?

	PixoPoint Menu Plugin
	Copyright (c) 2009 PixoPoint Web Development

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License version 2 as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

?>menu2_height=40|menu2_background_image=../images/dazzle_blue.png|menu2_background_colour=#203FA0|menu2_wrapperwidth=100|menu2_percent_wrapperwidth=%|menu2_containerwidth=100|menu2_percent_containerwidth=%|menu2_alignment=right|menu2_background_buttoncolour=#203FA0|menu2_background_buttonimage=../images/dazzle_blue.png|menu2_backgroundhovercolour=#4867C8|menu2_graphicalhover=on|menu2_button_betweenpadding=5|menu2_button_withinpadding=15|menu2_fontfamily=Georgia,serif|menu2_fontsize=16|menu2_fontweight=off|menu2_fontitalics=off|menu2_links_underline=Never underlined|menu2_texttransform=|menu2_letter_spacing=2|menu2_colour=#FFFFFF|menu2_hovercolour=#FFFFFF|menu2_dropdown_fontfamily=helvetica,arial,sans-serif|menu2_dropdown_textcolour=#262626|menu2_dropdown_texthovercolour=#FFFFFF|menu2_dropdown_backgroundcolour=#FFFFFF|menu2_dropdown_backgroundhovercolour=#203FA0|menu2_dropdown_width=130|menu2_dropdown_opacity=100|menu2_dropdown_paddingvertical=6|menu2_dropdown_paddinghorizontal=8|menu2_shadow_width=12|menu2_dropdown_fontsize=11|menu2_dropdown_bold=off|menu2_dropdown_italics=off|menu2_dropdown_texttransform=|menu2_dropdown_letter_spacing=0|menu2_dropdown_underline=Never underlined|menu2_dropdown_borderwidth=1|menu2_dropdown_bordercolour=#999999|
