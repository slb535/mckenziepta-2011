<?php

/*
	This file loads a new design
	Note: No this file does not need to be a PHP script, but why the heck not?

	PixoPoint Menu Plugin
	Copyright (c) 2009 PixoPoint Web Development

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License version 2 as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

?>menu2_height=25|menu2_background_image=../images/smoothfade_palered.png|menu2_background_colour=#FF5050|menu2_wrapperwidth=100|menu2_percent_wrapperwidth=%|menu2_containerwidth=100|menu2_percent_containerwidth=%|menu2_alignment=left|menu2_background_buttoncolour=#FF5050|menu2_background_buttonimage=../images/smoothfade_palered.png|menu2_backgroundhovercolour=#e92020|menu2_graphicalhover=off|menu2_button_betweenpadding=0|menu2_button_withinpadding=8|menu2_fontfamily=helvetica,arial,sans-serif|menu2_fontsize=12|menu2_fontweight=off|menu2_fontitalics=off|menu2_links_underline=Never underlined|menu2_texttransform=uppercase|menu2_letter_spacing_spacing=0|menu2_colour=#FFFFFF|menu2_hovercolour=#FFFFFF|menu2_dropdown_fontfamily=helvetica,arial,sans-serif|menu2_dropdown_textcolour=#444444|menu2_dropdown_texthovercolour=#444444|menu2_dropdown_backgroundcolour=#fcfcfc|menu2_dropdown_backgroundhovercolour=#dedede|menu2_dropdown_width=130|menu2_dropdown_opacity=100|menu2_dropdown_paddingvertical=6|menu2_dropdown_paddinghorizontal=8|menu2_shadow_width=12|menu2_dropdown_fontsize=11|menu2_dropdown_bold=off|menu2_dropdown_italics=off|menu2_dropdown_texttransform=|menu2_letter-spacing=0|menu2_dropdown_underline=Never underlined|menu2_dropdown_borderwidth=1|menu2_dropdown_bordercolour=#999999|
