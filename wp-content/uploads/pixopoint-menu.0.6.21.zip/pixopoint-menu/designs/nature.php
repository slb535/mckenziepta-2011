<?php

/*
	This file loads a new design
	Note: No this file does not need to be a PHP script, but why the heck not?

	PixoPoint Menu Plugin
	Copyright (c) 2009 PixoPoint Web Development

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License version 2 as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

?>menu1_height=24|menu1_background_image=|menu1_background_colour=#08770b|menu1_wrapperwidth=100|menu1_percent_wrapperwidth=%|menu1_containerwidth=100|menu1_percent_containerwidth=%|menu1_alignment=right|menu1_background_buttoncolour=#08770b|menu1_background_buttonimage=|menu1_backgroundhovercolour=#caf9c8|menu1_graphicalhover=off|menu1_button_betweenpadding=0|menu1_button_withinpadding=7|menu1_fontfamily=Palatino,serif|menu1_fontsize=13|menu1_fontweight=off|menu1_fontitalics=off|menu1_links_underline=Never underlined|menu1_texttransform=|menu1_letter_spacing_spacing=0|menu1_colour=#FFFFFF|menu1_hovercolour=#292929|menu1_dropdown_fontfamily=Palatino,serif|menu1_dropdown_textcolour=#333333|menu1_dropdown_texthovercolour=#333333|menu1_dropdown_backgroundcolour=#FFFFFF|menu1_dropdown_backgroundhovercolour=#caf9c8|menu1_dropdown_width=130|menu1_dropdown_opacity=100|menu1_dropdown_paddingvertical=6|menu1_dropdown_paddinghorizontal=8|menu1_shadow_width=12|menu1_dropdown_fontsize=11|menu1_dropdown_bold=off|menu1_dropdown_italics=off|menu1_dropdown_texttransform=|menu1_letter-spacing=0|menu1_dropdown_underline=Never underlined|menu1_dropdown_borderwidth=1|menu1_dropdown_bordercolour=#999999|
